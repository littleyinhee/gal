const props = {
    buttonProps: {
        type: Object,
    },
    icon: {
        type: String,
        value: '',
    },
    text: {
        type: String,
        value: '',
    },
};
export default props;
