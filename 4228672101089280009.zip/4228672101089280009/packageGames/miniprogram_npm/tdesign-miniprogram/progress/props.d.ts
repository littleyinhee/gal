import { TdProgressProps } from './type';
declare const props: TdProgressProps;
export default props;
