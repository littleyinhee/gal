import { TdSearchProps } from './type';
declare const props: TdSearchProps;
export default props;
