:: BASE_DOC ::

## API

### Result Props

name | type | default | description | required
-- | -- | -- | -- | --
description | String / Slot | - | \- | N
external-classes | Array | - | \- | N
icon | String | - | \- | N
image | String / Slot | - | \- | N
theme | String | default | \- | N
title | String / Slot | '' | \- | N
