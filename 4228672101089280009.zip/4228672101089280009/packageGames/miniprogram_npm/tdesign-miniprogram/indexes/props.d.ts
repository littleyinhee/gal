import { TdIndexesProps } from './type';
declare const props: TdIndexesProps;
export default props;
