import { TdFooterProps } from './type';
declare const props: TdFooterProps;
export default props;
