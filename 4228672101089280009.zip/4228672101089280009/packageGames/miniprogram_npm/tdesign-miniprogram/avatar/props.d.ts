import { TdAvatarProps } from './type';
declare const props: TdAvatarProps;
export default props;
