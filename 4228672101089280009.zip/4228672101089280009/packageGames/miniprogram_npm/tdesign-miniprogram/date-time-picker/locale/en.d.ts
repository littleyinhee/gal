declare const _default: {
    year: string;
    month: string;
    date: string;
    hour: string;
    minute: string;
    second: string;
    am: string;
    pm: string;
    confirm: string;
    cancel: string;
};
export default _default;
