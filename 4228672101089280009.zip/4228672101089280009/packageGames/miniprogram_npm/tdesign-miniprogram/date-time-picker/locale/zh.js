export default {
    year: '年',
    month: '月',
    date: '日',
    hour: '时',
    minute: '分',
    second: '秒',
    am: '上午',
    pm: '下午',
    confirm: '确定',
    cancel: '取消',
};
