# 游戏排序功能增强设计文档

## 概述

本设计文档描述了如何为现有的 Galgame 收藏小程序增强排序功能。系统将在现有的基础排序功能上，新增发行日期、开发商、平台数量、标签数量、标题长度等多种排序方式，以及开发商分组显示功能。

## 架构

### 整体架构
```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   UI Layer      │    │  Logic Layer    │    │   Data Layer    │
│                 │    │                 │    │                 │
│ - 排序选择器     │◄──►│ - 排序管理器     │◄──►│ - 游戏数据模型   │
│ - 分组显示组件   │    │ - 分组管理器     │    │ - 排序算法库     │
│ - 游戏列表组件   │    │ - 筛选控制器     │    │                 │
└─────────────────┘    └─────────────────┘    └─────────────────┘
```

### 模块划分
- **SortManager**: 排序管理模块，处理各种排序逻辑
- **GroupManager**: 分组管理模块，处理开发商分组显示
- **FilterController**: 筛选控制模块，协调排序和筛选的交互
- **UIComponents**: 界面组件，包括排序选择器和分组显示

## 组件和接口

### SortManager 排序管理器
```javascript
class SortManager {
  // 排序选项配置
  sortOptions: {
    default: { key: 'default', label: '默认排序', handler: 'defaultSort' },
    rating: { key: 'rating', label: '评分最高', handler: 'ratingSort' },
    name: { key: 'name', label: '名称排序', handler: 'nameSort' },
    date: { key: 'date', label: '最近游玩', handler: 'playDateSort' },
    releaseDate: { key: 'releaseDate', label: '发行日期', handler: 'releaseDateSort' },
    releaseDateClassic: { key: 'releaseDateClassic', label: '经典优先', handler: 'releaseDateClassicSort' },
    company: { key: 'company', label: '开发商', handler: 'companySort' },
    platformCount: { key: 'platformCount', label: '平台数量', handler: 'platformCountSort' },
    tagCount: { key: 'tagCount', label: '标签数量', handler: 'tagCountSort' },
    titleLength: { key: 'titleLength', label: '标题长度', handler: 'titleLengthSort' }
  }
  
  // 排序方法
  applySort(gameList, sortKey): Array
  releaseDateSort(gameList): Array
  releaseDateClassicSort(gameList): Array
  companySort(gameList): Array
  platformCountSort(gameList): Array
  tagCountSort(gameList): Array
  titleLengthSort(gameList): Array
}
```

### GroupManager 分组管理器
```javascript
class GroupManager {
  // 分组方法
  groupByCompany(gameList): Object
  
  // 分组显示配置
  groupConfig: {
    showGroupTitle: boolean,
    showGameCount: boolean,
    sortWithinGroup: string
  }
}
```

### FilterController 筛选控制器
```javascript
class FilterController {
  // 当前状态
  currentFilter: string
  currentSort: string
  isGroupMode: boolean
  
  // 控制方法
  applyFilterAndSort(filter, sort, groupMode): void
  updateDisplay(): void
}
```

## 数据模型

### 游戏数据扩展
现有游戏数据模型已包含所需字段，无需修改：
```javascript
{
  id: number,
  title: string,           // 用于标题长度排序
  company: string,         // 用于开发商排序和分组
  releaseDate: string,     // 用于发行日期排序
  platforms: Array,        // 用于平台数量排序
  tags: Array,            // 用于标签数量排序
  rating: number,
  status: string,
  // ... 其他现有字段
}
```

### 排序配置数据
```javascript
const SORT_CONFIG = {
  options: [
    { key: 'default', label: '默认排序', icon: '📋' },
    { key: 'rating', label: '评分最高', icon: '⭐' },
    { key: 'name', label: '名称排序', icon: '🔤' },
    { key: 'date', label: '最近游玩', icon: '📅' },
    { key: 'releaseDate', label: '发行日期', icon: '🗓️' },
    { key: 'releaseDateClassic', label: '经典优先', icon: '👑' },
    { key: 'company', label: '开发商', icon: '🏢' },
    { key: 'platformCount', label: '平台数量', icon: '📱' },
    { key: 'tagCount', label: '标签数量', icon: '🏷️' },
    { key: 'titleLength', label: '标题长度', icon: '📏' }
  ],
  groupOptions: [
    { key: 'none', label: '列表显示', icon: '📋' },
    { key: 'company', label: '开发商分组', icon: '🏢' }
  ]
}
```

## 错误处理

### 数据异常处理
- **缺失发行日期**: 将游戏排在列表末尾，显示"未知发行日期"
- **空开发商信息**: 归入"未知开发商"分组
- **无效平台数据**: 平台数量视为0
- **空标签数组**: 标签数量视为0
- **空标题**: 标题长度视为0

### 排序异常处理
- **排序过程出错**: 回退到默认排序，显示错误提示
- **分组失败**: 回退到列表显示模式
- **数据类型错误**: 使用默认值进行排序

### 用户体验异常
- **排序响应慢**: 显示加载状态，超时后提示用户
- **选项过多**: 提供水平滚动和搜索功能
- **状态丢失**: 使用本地存储保存用户偏好

## 测试策略

本项目将采用双重测试方法：单元测试验证具体功能，属性测试验证通用正确性。

### 单元测试
- 测试各种排序算法的正确性
- 测试分组功能的准确性
- 测试异常数据的处理
- 测试用户界面交互

### 属性测试
属性测试将使用 **fast-check** 库进行，每个测试运行最少100次迭代以确保可靠性。

## 正确性属性

*属性是一个特征或行为，应该在系统的所有有效执行中保持为真——本质上是关于系统应该做什么的正式声明。属性作为人类可读规范和机器可验证正确性保证之间的桥梁。*

### 排序正确性属性

**属性 1: 发行日期排序一致性**
*对于任何* 游戏列表，按发行日期排序后，列表中任意相邻的两个游戏，前一个游戏的发行日期应该晚于或等于后一个游戏的发行日期
**验证需求: Requirements 1.1**

**属性 2: 经典优先排序一致性**
*对于任何* 游戏列表，按经典优先排序后，列表中任意相邻的两个游戏，前一个游戏的发行日期应该早于或等于后一个游戏的发行日期
**验证需求: Requirements 1.2**

**属性 3: 缺失发行日期处理**
*对于任何* 包含缺失发行日期游戏的列表，按发行日期排序后，所有缺失发行日期的游戏应该出现在列表末尾
**验证需求: Requirements 1.3**

**属性 4: 开发商排序一致性**
*对于任何* 游戏列表，按开发商排序后，列表中任意相邻的两个游戏，前一个游戏的开发商名称在字母顺序上应该小于或等于后一个游戏
**验证需求: Requirements 2.1**

**属性 5: 平台数量排序一致性**
*对于任何* 游戏列表，按平台数量排序后，列表中任意相邻的两个游戏，前一个游戏的平台数量应该大于或等于后一个游戏的平台数量
**验证需求: Requirements 3.1**

**属性 6: 标签数量排序一致性**
*对于任何* 游戏列表，按标签数量排序后，列表中任意相邻的两个游戏，前一个游戏的标签数量应该大于或等于后一个游戏的标签数量
**验证需求: Requirements 4.1**

**属性 7: 标题长度排序一致性**
*对于任何* 游戏列表，按标题长度排序后，列表中任意相邻的两个游戏，前一个游戏的标题长度应该大于或等于后一个游戏的标题长度
**验证需求: Requirements 5.1**

### 分组正确性属性

**属性 8: 开发商分组完整性**
*对于任何* 游戏列表，按开发商分组后，每个游戏都应该且仅应该出现在一个开发商组中，且组名与游戏的开发商名称匹配
**验证需求: Requirements 6.1**

**属性 9: 分组内排序一致性**
*对于任何* 开发商分组结果，每个组内的游戏应该按评分从高到低排序
**验证需求: Requirements 6.3**

**属性 10: 大小写不敏感分组**
*对于任何* 包含相同开发商但大小写不同的游戏列表，分组后这些游戏应该被归入同一个组
**验证需求: Requirements 6.4**

### 数据处理正确性属性

**属性 11: 平台数量计算准确性**
*对于任何* 游戏，其平台数量应该等于其平台数组的长度，空数组的长度为0
**验证需求: Requirements 3.4**

**属性 12: 标签数量计算准确性**
*对于任何* 游戏，其标签数量应该等于其标签数组的长度，空数组的长度为0
**验证需求: Requirements 4.4**

**属性 13: 多语言标题长度计算**
*对于任何* 游戏标题，无论包含中文、英文还是特殊字符，标题长度计算应该返回正确的字符数
**验证需求: Requirements 5.3**

### 状态管理正确性属性

**属性 14: 筛选状态保持**
*对于任何* 当前筛选状态，切换排序选项后，筛选状态应该保持不变
**验证需求: Requirements 7.4**

**属性 15: 排序选项状态一致性**
*对于任何* 排序选项选择，系统应该正确高亮显示当前选中的选项，且只有一个选项处于选中状态
**验证需求: Requirements 7.1**

属性测试要求：
- 每个属性测试必须用注释明确标注对应的设计文档属性
- 使用格式：`// **Feature: game-sorting-enhancement, Property {number}: {property_text}**`
- 每个正确性属性必须对应一个独立的属性测试
- 测试必须验证真实功能，不使用模拟数据

## 实现细节

### 排序算法实现

#### 发行日期排序
```javascript
releaseDateSort(gameList) {
  return gameList.sort((a, b) => {
    const dateA = a.releaseDate ? new Date(a.releaseDate) : new Date(0);
    const dateB = b.releaseDate ? new Date(b.releaseDate) : new Date(0);
    
    if (dateA.getTime() === dateB.getTime()) {
      return a.title.localeCompare(b.title);
    }
    return dateB.getTime() - dateA.getTime(); // 新到旧
  });
}
```

#### 开发商分组实现
```javascript
groupByCompany(gameList) {
  const groups = {};
  
  gameList.forEach(game => {
    const company = game.company ? game.company.toLowerCase() : '未知开发商';
    if (!groups[company]) {
      groups[company] = {
        name: game.company || '未知开发商',
        games: []
      };
    }
    groups[company].games.push(game);
  });
  
  // 组内按评分排序
  Object.values(groups).forEach(group => {
    group.games.sort((a, b) => b.rating - a.rating);
  });
  
  return groups;
}
```

### 用户界面设计

#### 排序选择器布局
```xml
<view class="sort-section">
  <scroll-view scroll-x class="sort-scroll">
    <view class="sort-item {{currentSort === 'default' ? 'active' : ''}}" 
          bindtap="onSortChange" data-sort="default">
      📋 默认排序
    </view>
    <view class="sort-item {{currentSort === 'releaseDate' ? 'active' : ''}}" 
          bindtap="onSortChange" data-sort="releaseDate">
      🗓️ 发行日期
    </view>
    <!-- 其他排序选项... -->
  </scroll-view>
</view>
```

#### 分组显示布局
```xml
<view class="group-display" wx:if="{{isGroupMode}}">
  <view class="company-group" wx:for="{{groupedGames}}" wx:key="name">
    <view class="group-header">
      <text class="group-title">{{item.name}}</text>
      <text class="group-count">({{item.games.length}})</text>
    </view>
    <view class="group-games">
      <view class="game-card" wx:for="{{item.games}}" wx:key="id">
        <!-- 游戏卡片内容 -->
      </view>
    </view>
  </view>
</view>
```

### 性能优化

#### 排序缓存策略
- 对于相同的排序条件，缓存排序结果
- 当数据发生变化时，清除相关缓存
- 使用防抖技术避免频繁排序操作

#### 大数据集处理
- 对于超过100个游戏的列表，使用虚拟滚动
- 分页加载分组结果
- 异步排序避免阻塞UI线程

## 兼容性考虑

### 数据向下兼容
- 新增的排序功能不影响现有数据结构
- 缺失字段使用默认值处理
- 保持现有API接口不变

### 用户体验平滑过渡
- 保留用户之前的排序偏好
- 新功能渐进式引导
- 提供功能开关选项

## 部署和维护

### 发布策略
1. 灰度发布：先向10%用户开放新功能
2. 监控反馈：收集用户使用数据和反馈
3. 全量发布：确认稳定后全量开放

### 监控指标
- 排序操作响应时间
- 各排序选项使用频率
- 分组功能使用率
- 错误率和崩溃率

### 维护计划
- 定期优化排序算法性能
- 根据用户反馈调整排序选项
- 监控和修复兼容性问题