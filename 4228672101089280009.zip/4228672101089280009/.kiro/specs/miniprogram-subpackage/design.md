# Design Document: 微信小程序分包优化

## Overview

本设计文档描述了微信小程序分包加载的实现方案。通过分析当前项目结构，将页面、npm依赖和图片资源合理分配到主包和分包中，解决包体积超限问题。

### 当前问题分析

根据项目结构分析，体积大户主要是：
1. `miniprogram_npm/tdesign-miniprogram` - TDesign组件库（体积较大）
2. `miniprogram_npm/edu-miniprogram-components` - 教育组件库
3. `images/covers` - 游戏封面图片（约27个图片文件）

### 分包策略

```
主包 (Main Package)
├── pages/index/          # 首页（启动页）
├── app.js
├── app.json
└── app.wxss

分包: packageGames
├── pages/
│   ├── games/            # 游戏列表页
│   └── game-detail/      # 游戏详情页
├── images/covers/        # 游戏封面图片
└── miniprogram_npm/      # npm依赖（tdesign组件）
    └── tdesign-miniprogram/

主包保留的npm依赖
└── miniprogram_npm/
    └── edu-miniprogram-components/  # 首页使用的组件
```

## Architecture

```mermaid
graph TB
    subgraph MainPackage[主包 ≤2MB]
        Index[pages/index]
        EduComponents[edu-miniprogram-components]
        Index --> EduComponents
    end
    
    subgraph SubPackage[分包: packageGames]
        Games[pages/games]
        GameDetail[pages/game-detail]
        TDesign[tdesign-miniprogram]
        Images[images/covers]
        Games --> TDesign
        Games --> Images
        GameDetail --> TDesign
        GameDetail --> Images
    end
    
    Index -.->|预下载| SubPackage
    Index -->|跳转| Games
    Games -->|跳转| GameDetail
```

## Components and Interfaces

### app.json 配置结构

```json
{
  "pages": [
    "pages/index/index"
  ],
  "subpackages": [
    {
      "root": "packageGames",
      "name": "games",
      "pages": [
        "pages/games/games",
        "pages/game-detail/game-detail"
      ]
    }
  ],
  "preloadRule": {
    "pages/index/index": {
      "network": "all",
      "packages": ["games"]
    }
  }
}
```

### 目录结构变更

**变更前：**
```
├── pages/
│   ├── index/
│   ├── games/
│   └── game-detail/
├── images/
│   └── covers/
└── miniprogram_npm/
    ├── edu-miniprogram-components/
    └── tdesign-miniprogram/
```

**变更后：**
```
├── pages/
│   └── index/                    # 主包页面
├── miniprogram_npm/
│   └── edu-miniprogram-components/  # 主包npm依赖
└── packageGames/                 # 分包根目录
    ├── pages/
    │   ├── games/
    │   └── game-detail/
    ├── images/
    │   └── covers/
    └── miniprogram_npm/
        └── tdesign-miniprogram/
```

## Data Models

### 分包配置模型

| 字段 | 类型 | 说明 |
|------|------|------|
| root | string | 分包根目录 |
| name | string | 分包别名，用于预下载 |
| pages | string[] | 分包内的页面路径（相对于root） |
| independent | boolean | 是否为独立分包（可选） |

### 预下载规则模型

| 字段 | 类型 | 说明 |
|------|------|------|
| network | string | 网络类型：all/wifi |
| packages | string[] | 要预下载的分包name或root |

## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system-essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

由于本功能主要涉及配置文件修改和目录结构调整，大部分验证依赖微信开发者工具的构建检查，不适合编写自动化属性测试。以下是需要手动验证的关键点：

### 验证清单（手动检查）

1. **配置正确性**: app.json中的subpackages和preloadRule配置语法正确
2. **路径一致性**: 分包内页面的组件引用路径与实际目录结构一致
3. **构建成功**: 微信开发者工具能够成功构建项目
4. **体积达标**: 主包体积≤2MB，单个分包体积≤2MB

## Error Handling

### 常见错误及解决方案

| 错误 | 原因 | 解决方案 |
|------|------|----------|
| 分包页面找不到组件 | 组件路径未更新 | 更新usingComponents中的路径为分包相对路径 |
| 图片加载失败 | 图片路径未更新 | 更新wxml中的图片src为分包路径 |
| 主包仍然超限 | npm依赖未正确分离 | 检查主包页面是否引用了分包内的组件 |
| 预下载失败 | preloadRule配置错误 | 检查packages数组中的分包名称是否正确 |

## Testing Strategy

### 验证方式

由于微信小程序分包是平台级功能，主要通过以下方式验证：

1. **开发者工具验证**
   - 使用微信开发者工具的"详情"面板查看包体积
   - 确认主包和分包体积均在限制范围内

2. **功能测试**
   - 冷启动小程序，确认首页正常加载
   - 从首页跳转到games页面，确认分包加载正常
   - 从games跳转到game-detail，确认页面正常显示
   - 检查所有图片是否正常显示

3. **预下载验证**
   - 在开发者工具中观察网络请求
   - 确认进入首页后分包开始预下载

### 测试框架

本功能不需要单元测试或属性测试，主要依赖手动验证和微信开发者工具的构建检查。
