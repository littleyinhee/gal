# Implementation Plan

- [ ] 1. 创建分包目录结构
  - [ ] 1.1 创建 packageGames 分包根目录
    - 创建 `packageGames/pages/games/` 目录
    - 创建 `packageGames/pages/game-detail/` 目录
    - 创建 `packageGames/images/covers/` 目录
    - 创建 `packageGames/miniprogram_npm/` 目录
    - _Requirements: 1.4_

- [ ] 2. 迁移页面文件到分包
  - [ ] 2.1 迁移 games 页面
    - 将 `pages/games/` 下的所有文件移动到 `packageGames/pages/games/`
    - _Requirements: 1.1, 1.3_
  - [ ] 2.2 迁移 game-detail 页面
    - 将 `pages/game-detail/` 下的所有文件移动到 `packageGames/pages/game-detail/`
    - _Requirements: 1.1, 1.3_

- [ ] 3. 迁移资源文件到分包
  - [ ] 3.1 迁移图片资源
    - 将 `images/covers/` 下的所有文件移动到 `packageGames/images/covers/`
    - _Requirements: 4.1_
  - [ ] 3.2 迁移 tdesign-miniprogram npm依赖
    - 将 `miniprogram_npm/tdesign-miniprogram/` 移动到 `packageGames/miniprogram_npm/tdesign-miniprogram/`
    - _Requirements: 3.1_

- [ ] 4. 更新分包页面的组件引用路径
  - [ ] 4.1 更新 games.json 组件路径
    - 将组件路径从 `/miniprogram_npm/tdesign-miniprogram/` 改为相对路径 `../../miniprogram_npm/tdesign-miniprogram/`
    - _Requirements: 3.2_
  - [ ] 4.2 更新 game-detail.json 组件路径
    - 将组件路径从 `/miniprogram_npm/tdesign-miniprogram/` 改为相对路径 `../../miniprogram_npm/tdesign-miniprogram/`
    - _Requirements: 3.2_

- [ ] 5. 更新分包页面的图片引用路径
  - [ ] 5.1 更新 games.wxml 图片路径
    - 检查并更新所有图片src路径，使用分包内的相对路径
    - _Requirements: 4.2_
  - [ ] 5.2 更新 game-detail.wxml 图片路径
    - 检查并更新所有图片src路径，使用分包内的相对路径
    - _Requirements: 4.2_
  - [ ] 5.3 更新 games.js 中的图片路径引用
    - 检查并更新JS文件中的图片路径常量或变量
    - _Requirements: 4.2_

- [ ] 6. 更新 app.json 配置
  - [ ] 6.1 配置分包
    - 从 pages 数组中移除 games 和 game-detail 页面
    - 添加 subpackages 配置，定义 packageGames 分包
    - _Requirements: 1.1, 1.2_
  - [ ] 6.2 配置分包预下载
    - 添加 preloadRule 配置，在首页预下载 games 分包
    - _Requirements: 5.1, 5.2_

- [ ] 7. 更新页面跳转路径
  - [ ] 7.1 更新首页跳转路径
    - 检查 index.js 中的页面跳转，更新为分包路径 `/packageGames/pages/games/games`
    - _Requirements: 2.3_
  - [ ] 7.2 更新 games 页面跳转路径
    - 检查 games.js 中跳转到 game-detail 的路径，更新为 `/packageGames/pages/game-detail/game-detail`
    - _Requirements: 1.3_

- [ ] 8. 清理原目录
  - [ ] 8.1 删除原 pages/games 目录
    - 确认迁移成功后删除原目录
    - _Requirements: 1.1_
  - [ ] 8.2 删除原 pages/game-detail 目录
    - 确认迁移成功后删除原目录
    - _Requirements: 1.1_
  - [ ] 8.3 删除原 images/covers 目录
    - 确认迁移成功后删除原目录
    - _Requirements: 4.1_
  - [ ] 8.4 删除原 miniprogram_npm/tdesign-miniprogram 目录
    - 确认迁移成功后删除原目录
    - _Requirements: 3.1_

- [ ] 9. Checkpoint - 验证分包配置
  - Ensure all tests pass, ask the user if questions arise.
