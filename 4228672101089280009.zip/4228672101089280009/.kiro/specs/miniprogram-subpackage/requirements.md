# Requirements Document

## Introduction

本规范定义了微信小程序分包加载优化功能，旨在解决小程序主包体积超过平台限制（2MB）的问题。通过将页面和资源合理分配到不同的分包中，实现按需加载，提升小程序的加载性能和用户体验。

## Glossary

- **主包 (Main Package)**: 小程序启动时必须下载的包，包含启动页面和公共资源，大小限制为2MB
- **分包 (Subpackage)**: 按需下载的独立包，用户访问分包页面时才会下载，单个分包限制为2MB
- **独立分包 (Independent Subpackage)**: 可以独立于主包运行的分包，支持从分包页面直接启动小程序
- **分包预下载 (Preload Subpackage)**: 在进入某个页面时预先下载指定分包，提升后续页面访问速度
- **miniprogram_npm**: 小程序的npm依赖包目录

## Requirements

### Requirement 1

**User Story:** As a 小程序开发者, I want to 将页面拆分到不同分包中, so that 主包体积能够控制在平台限制范围内。

#### Acceptance Criteria

1. WHEN 小程序配置分包后 THEN 系统 SHALL 将主包体积控制在2MB以内
2. WHEN 用户访问主包页面 THEN 系统 SHALL 仅加载主包资源
3. WHEN 用户访问分包页面 THEN 系统 SHALL 按需下载对应分包
4. WHEN 配置分包路径 THEN 系统 SHALL 确保分包根目录与主包pages目录平级

### Requirement 2

**User Story:** As a 小程序用户, I want to 快速打开小程序首页, so that 我能够获得流畅的使用体验。

#### Acceptance Criteria

1. WHEN 用户启动小程序 THEN 系统 SHALL 仅下载主包内容
2. WHEN 主包加载完成 THEN 系统 SHALL 立即显示首页内容
3. WHEN 首页需要跳转到分包页面 THEN 系统 SHALL 预下载目标分包

### Requirement 3

**User Story:** As a 小程序开发者, I want to 将npm依赖包分包处理, so that 第三方库不会占用主包空间。

#### Acceptance Criteria

1. WHEN 配置分包后 THEN 系统 SHALL 支持将miniprogram_npm目录移至分包
2. WHEN 分包页面引用npm组件 THEN 系统 SHALL 从分包内的npm目录加载组件
3. WHEN 主包页面不使用npm组件 THEN 系统 SHALL 不在主包中包含npm依赖

### Requirement 4

**User Story:** As a 小程序开发者, I want to 将图片资源分包处理, so that 大体积的图片资源不会影响主包大小。

#### Acceptance Criteria

1. WHEN 配置分包后 THEN 系统 SHALL 支持将images目录移至分包
2. WHEN 分包页面引用图片 THEN 系统 SHALL 使用分包内的图片路径
3. WHEN 图片资源较大 THEN 系统 SHALL 建议使用网络图片替代本地图片

### Requirement 5

**User Story:** As a 小程序开发者, I want to 配置分包预下载策略, so that 用户在访问分包页面时能够快速加载。

#### Acceptance Criteria

1. WHEN 用户进入首页 THEN 系统 SHALL 根据配置预下载指定分包
2. WHEN 配置预下载规则 THEN 系统 SHALL 支持按网络类型区分下载策略
3. WHEN 预下载完成 THEN 系统 SHALL 缓存分包内容供后续使用
